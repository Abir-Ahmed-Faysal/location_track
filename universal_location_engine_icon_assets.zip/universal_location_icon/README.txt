Universal Location Engine icon assets

Files:
- universal_location_engine.svg: editable vector source artwork (512x512)
- android/res/drawable/ic_location_engine_background.xml: Android adaptive icon background
- android/res/drawable/ic_location_engine_foreground.xml: Android vector foreground
- android/res/mipmap-anydpi-v26/ic_launcher.xml: adaptive icon definition for Android 8.0+

Integration:
1. Copy the contents of android/res/ into your app/src/main/res/ folder.
2. In app/src/main/AndroidManifest.xml, set android:icon="@mipmap/ic_launcher" on <application>.
3. If your app uses android:roundIcon, either create a round adaptive icon resource or point it to @mipmap/ic_launcher.
4. For API 24-25, provide legacy launcher PNG assets in mipmap-mdpi, mipmap-hdpi, mipmap-xhdpi, mipmap-xxhdpi, and mipmap-xxxhdpi. The adaptive icon resource is used on API 26+.

The SVG is design/source artwork; Android launcher icons should use adaptive icon XML + vector drawables, plus legacy PNGs for API 24-25.
